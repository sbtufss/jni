#include <jni.h>

JNIEXPORT jstring JNICALL
Java_com_example_sbtufss_jni_MainActivity_sayHelloFromOtherLib(JNIEnv *env, jobject instance) {

    // TODO


    return (*env)->NewStringUTF(env, "sayHelloFromOtherLib");
}

